
while : 
do
echo "${blue} Iniciando..Anita Bot..."
    node anita.js
    sleep 1

done
